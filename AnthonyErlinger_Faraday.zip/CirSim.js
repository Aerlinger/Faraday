/////////////////////////////////////////////////////////////////////////////////
// CirSim: Core circuit computation and node management
/////////////////////////////////////////////////////////////////////////////////

CirSim.MODE_ADD_ELM = 0;
CirSim.MODE_DRAG_ALL = 1;
CirSim.MODE_DRAG_ROW = 2;
CirSim.MODE_DRAG_COLUMN = 3;
CirSim.MODE_DRAG_SELECTED = 4;
CirSim.MODE_DRAG_POST = 5;
CirSim.MODE_SELECT = 6;

CirSim.mouseMode = CirSim.MODE_SELECT;
CirSim.tempMouseMode = CirSim.MODE_SELECT;

CirSim.dragX = 0;
CirSim.dragY = 0;
CirSim.initDragX = 0;
CirSim.initDragY = 0;

CirSim.selectedArea = new Rectangle(0, 0, 0, 0);

CirSim.gridSize = 10;
CirSim.gridMask = 10;
CirSim.gridRound = 10;

CirSim.dragging = false;
CirSim.analyzeFlag = true;
CirSim.dumpMatrix = false;

CirSim.t = 0;
CirSim.pause = 10;

CirSim.menuScope = -1;
CirSim.hintType = -1;
CirSim.hintItem1 = -1;
CirSim.hintItem2 = -1;
CirSim.stopMessage = 0;

CirSim.HINT_LC = 1;
CirSim.HINT_RC = 2;
CirSim.HINT_3DB_C = 3;
CirSim.HINT_TWINT = 4;
CirSim.HINT_3DB_L = 5;


CirSim.setupList = [];

// Simulation state variables ///////////////////////

CirSim.stoppedCheck = false;
CirSim.showPowerCheck = false;
CirSim.showValuesCheckItem = true;
CirSim.powerCheckItem = false;
CirSim.voltsCheckItem = true;
CirSim.dotsCheckItem = true;
CirSim.printableCheckItem = false;
CirSim.conventionCheckItem = true;
CirSim.speedBar = 117;
CirSim.currentBar = 50;
CirSim.smallGridCheckItem = false;
CirSim.powerBar = 50;

CirSim.timeStep = 1e-6;
CirSim.converged = true;
CirSim.subIterations = 5000;
////////////////////////////////////////////////////

CirSim.dragElm = null;
CirSim.menuElm = null;
CirSim.mouseElm = null;
CirSim.stopElm = null;

CirSim.mousePost = -1;
CirSim.plotXElm = null;
CirSim.plotYElm = null;
CirSim.draggingPost = 0;
CirSim.heldSwitchElm;

// Todo: Implement Scopes
CirSim.Scopes = [];
CirSim.scopeCount = 0;
CirSim.scopeSelected = -1;
CirSim.scopeColCount = [];

CirSim.muString = "u";
CirSim.ohmString = "ohm";

CirSim.root
//public var useFrame:Boolean;

CirSim.elmList = [];
CirSim.nodeList = [];
CirSim.voltageSources = [];

// Circuit data Arrays: //////////////////////////////////////////////////////////
CirSim.circuitMatrix = [];
// Two dimensional floating point array;
CirSim.circuitRightSide = [];
// Column vector (floating point)
CirSim.origRightSide = [];
// Column vector floating point
CirSim.origMatrix = [];
// Two dimensional floating point array;

CirSim.circuitRowInfo = []; // Array of RowInfo Elements

CirSim.circuitPermute = []; // Array of integers

CirSim.scaleFactors = new Array();
//////////////////////////////////////////////////////////////////////////////////

CirSim.circuitNonLinear = false;

CirSim.voltageSourceCount = 0;

CirSim.circuitMatrixSize;
CirSim.circuitMatrixFullSize;
CirSim.circuitNeedsMap;

CirSim.editDialog;
CirSim.impDialog;

CirSim.clipboard = "";

CirSim.circuitArea;
CirSim.circuitBottom;
CirSim.undoStack = [];
CirSim.redoStack = [];

CirSim.startCircuit = null;
CirSim.startLabel = null;
CirSim.startCircuitText = null;
CirSim.baseURL = "";

// Simulation tracking variables:
CirSim.lastTime     = 0;
CirSim.lastFrameTime = 0;
CirSim.lastIterTime = 0;
CirSim.secTime      = 0;
CirSim.frames       = 0;
CirSim.steps        = 0;
CirSim.framerate    = 0;
CirSim.steprate     = 0;

CirSim.dumpTypes = [];
//= new Dictionary();	// Array of classes
CirSim.menuMapping = [];
// new Dictionary();

CirSim.useFrame = false;

var date = new Date();


///////////////////////////////////////////////////////////////////////
// CirSim Constructor: ////////////////////////////////////////////////
function CirSim() {
	console.log("Started simulation");
};

CirSim.register = function( elmClassName ) {

    // TODO IMPLEMENT
//    var elm = constructElement(elmClassName, 0, 0, 0, 0, 0, null);
//    var dumpType = elm.getDumpType();
//
//    var dclass = elmClassName;//elmClassName.getDumpClass();
//    if(dumpTypes[dumpType] == dclass)
//        return;
//    if( dumpTypes[dumpType] != null) {
//        console.log("Dump type conflict: " + dumpType + " " + dumpTypes[dumpType]);
//        return;
//    }
//
//    dumpTypes[dumpType] = dclass;
};

CirSim.constructElement = function(className, xa, ya, xb, yb, f, st) {

//    var newElm:CircuitElement;
//
//    var classDef:Class = Class(getDefinitionByName(className));
//
//    newElm = new classDef(xa, ya, xb, yb, f, st);
//
//    return newElm;
    // todo: test and try to find replacement for eval
    var newElm = eval( "new " + className + "(" + xa + "," + xb + "," + xb + "," + f + "," + st + ");" );
};

CirSim.init = function() {
    // TODO IMPLEMENT
//    var euroResistor = null;
//    var useFrameStr = null;
//
//    var printable = false;
//    var convention = true;
//
//    //initScaleFactors();
//
    CircuitElement.initClass();
//
    CirSim.needAnalyze();
//
//    /////////////////////////////////////////
//    // Set up UI Here:
//    /////////////////////////////////////////
//
//    try {
//        baseURL = "/";
//        //baseURL = applet.getDocumentBase().getFile(); // JAVA code
//        // Look for circuit embedded in URL:
//        //var doc:String = applet.getDocumentBase.toString();		// JAVA code
//        var doc:String = "";		// JAVA code
//
//        var idx:int = doc.indexOf('#');
//
//        if(idx > 0) {
//            var x:String = null;
//
//            try {
//                x = doc.substring(idx + 1);	// JAVA code
//
//                //x = URLDecoder.decoder(x); // JAVA code
//                //x = unescape(x);
//                x = decodeURI(x);
//
//                startCircuitText = x;
//            } catch ( E:Error ) {
//                console.log("Can't decode " + x);
//            }
//        }
//
//        idx = doc.lastIndexOf('/');
//
//        if(idx > 0)
//            baseURL = doc.substring(0, idx + 1);
//
//        //var param:String = applet.getParameter("PAUSE");	// JAVA code
//        //startCircuit 	= applet.getParameter("startCircuit");
//        //startLabel 		= applet.getParameter("startLabel");
//        //euroResistor 	= applet.getParameter("euroResistors");
//        //useFrameStr 	= applet.getParameter("useFrame");
//
//        //var x:String	= applet.getParameter("whiteBackground");
//
//        //if(x != null && x.toLowerCase() == "true" )
//        //	printable = true;
//
//        //x = applet.getParameter("conventionalCurrent");
//
//        //if( x 1+ null && x.toLowerCase() == "true" )
//        //	convention = false;
//
//    } catch( E:Error ) {
//    }
//
//    registerAll();
//
//    //var euro = false; //(euroResistor != null && euroResistor.equalsIgnoreCase("true") );
//    //useFrame = (useFrameStr == null || useFrameStr.equalsIgnoreCase("false") );
//
//    //if(useFrame)
//    //main = this;
//    //else
//    //	main = applet;
//
//    //dumpTypes = new Array(300);
//
//
//    //			dumpTypes[(int) 'o'] = Scope.class;
//    //			dumpTypes[(int) 'h'] = Scope.class;
//    //			dumpTypes[(int) '$'] = Scope.class;
//    //			dumpTypes[(int) '%'] = Scope.class;
//    //			dumpTypes[(int) '?'] = Scope.class;
//    //			dumpTypes[(int) 'B'] = Scope.class;
//
    CirSim.setGrid();
    CirSim.elmList = new Array();
//    setupList = new Array();
//    undoStack = new Array();
//    redoStack = new Array();
//
//    loadSetupFile();

    CirSim.circuitArea = CanvasBoundingBox;

};

CirSim.registerAll = function() {
    // TODO IMPLEMENT
//
//    var mosfetElm:MosfetElm;
//    var diodeElm:DiodeElm;
//
//    register("elements.ResistorElm");
//    register("elements.CapacitorElm");
//    register("elements.SwitchElm");
//    register("elements.GroundElm");
//    register("elements.WireElm");
//    register("elements.VoltageElm");
//    register("elements.RailElm");
//    register("elements.InductorElm");
//    register("elements.DiodeElm");
//
//    //			register("elements.OutputElm");
//    register("elements.MosfetElm");
//    //			register("elements.NMosfetElm");
//    //			register("elements.PMosfetElm");

};

/** Reads a circuit from a string buffer after loaded from from file. Called when the defaultCircuitFile is finished loading*/
CirSim.readDefaultCircuit = function(b, len, retain) {
    // TODO IMPLEMENT
//    if (!retain) {
//
//        // reset the interface
//        for (var i = 0; i < elmList.length; i++) {
//            var ce:CircuitElement = getElm(i);
//            ce.destroy();
//        }
//
//        elmList.removeAllElements();
//        hintType = -1;
//        timeStep = 5e-6;
//
//        dotsCheckItem = true;
//        smallGridCheckItem = false;
//        powerCheckItem = false;
//        voltsCheckItem = true;
//        showValuesCheckItem = true;
//        setGrid();
//        speedBar = 117; // 57
//        currentBar = 50;
//        powerBar = 50;
//        CircuitElement.voltageRange = 5;
//        scopeCount = 0;
//
//    }
//
//    for (var p:uint = 0; p < len;) {
//
//        var l:int;
//        var linelen:int = 0;
//        for (l = 0; l != len - p; l++) {
//            if (b.charAt(l + p) == '\n' || b.charAt(l + p) == '\r') {
//                linelen = l++;
//                if (l + p < b.length && b.charAt(l + p) == '\n')
//                    l++;
//                break;
//            }
//        }
//
//        var line:String = b.substring(p, p+linelen);
//        var st:StringTokenizer = new StringTokenizer( line, " " );
//
//        while ( st.hasMoreTokens() ) {
//
//            var type:String = st.nextToken();
//            var tint:String 	= type.charAt(0);
//
//            try {
//                // Scope input
//                if (tint == 'o') {
//                    //var sc:Scope = new Scope(this);
//                    //sc.position = scopeCount;
//                    //sc.undump(st);
//                    //scopes[scopeCount++] = sc;
//                    break;
//                }
//                if (tint == ('h')) {
//                    readHint(st);
//                    break;
//                }
//                if (tint == ('$')) {
//                    readOptions(st);
//                    break;
//                }
//                if (tint == ('%') || tint == ('?') || tint == ('B')) {
//                    // ignore filter-specific stuff
//                    break;
//                }
//                //if (tint >= ('0') && tint <= ('9'))
//                //	tint = int(type);
//
//
//                var x1:int = int(st.nextToken());
//                var y1:int = int(st.nextToken());
//                var x2:int = int(st.nextToken());
//                var y2:int = int(st.nextToken());
//                var f:int = int(st.nextToken());
//
//                var cls:String = dumpTypes[tint];
//
//                if (cls == null) {
//                    console.log("unrecognized dump type: " + type);
//                    break;
//                }
//
//                // NEW ELEMENTS ARE INSTANTIATED HERE
//                //console.log("run: " + cls + " " + " " + st.nextToken() + " " + st.nextToken() + " " + st.nextToken() );
//                var ce:CircuitElement = constructElement(cls, int(x1), int(y1), int(x2), int(y2), int(f), st);
//                ce.setPoints();
//
//                // Add the element to the Element list
//                elmList.push(ce);
//            } catch ( ee:Error ) {
//                console.log("Error reading circuit file: " + ee.getStackconsole.log) );
//                break;
//            }
//            break;
//        }
//        p += l;
//
//    }
//
//    var dumpMessage:String = dumpCircuit();
//
//    if (!retain)
//        handleResize(); // for scopes
//
//    needAnalyze();
//    handleResize();
//
//    //initCircuit();
//    console.log("dump: \n" + dumpMessage);
//
//    /////////////////////////////////////////////////////////////
//    // Once the input files have been loaded
//    // Simulation starts here.
//    /////////////////////////////////////////////////////////////
//    root.start();

};


CirSim.initCircuit = function() {
	for(var i = 0; i != CirSim.elmList.length; i++) {
		var ce = CirSim.getElm(i);
		ce.destroy();
	}

	CirSim.elmList = [];
	CirSim.setGrid();

	////////////////////////////////////////////////////////
	// TODO: ELEMENT INSTANTIATION GOES HERE:
	////////////////////////////////////////////////////////

//    var ClassSubPath:String = "elements.";
    var voltageElm = new VoltageElm(304, 85, 368, 85, 0, "1 4000.0 15.0, 0.0, 0.0, 0.5");
    voltageElm.setPoints();

    var switchElm = new SwitchElm(368, 100, 368, 160, 0, "true false");
    switchElm.setPoints();

    var resistorElm = new ResistorElm(368, 160, 368, 220, 0, "5000");
    resistorElm.setPoints();

    var inductorElm = new InductorElm(368, 220, 368, 300, 0, ".01 0");
    inductorElm.setPoints();

    //var capacitorElm = new DiodeElm(368, 300, 368, 400, 0, "6.25e-6 0");
    var diodeElm = new CapacitorElm(368, 300, 368, 400, 0, "6.25e-7 0");
    diodeElm.setPoints();

    var groundElm = new GroundElm(368, 400, 368, 440, 0, null);
    groundElm.setPoints();

    var groundElm2 = new GroundElm(304, 100, 304, 440, 0, null);
    groundElm2.setPoints();


    CirSim.elmList.push(voltageElm);
    CirSim.elmList.push(groundElm2);
    CirSim.elmList.push(resistorElm);
    CirSim.elmList.push(groundElm);
    CirSim.elmList.push(switchElm);
    CirSim.elmList.push(inductorElm);
    CirSim.elmList.push(diodeElm);


//    // Initialization!
//    var voltageElm:RailElm = constructElement(ClassSubPath + "RailElm", 368, 100, 304, 100, 0, new StringTokenizer("0 40.0 15.0 0.0 0.0 0.5"));
//    voltageElm.setPoints();
//
//    var switchElm:SwitchElm = constructElement(ClassSubPath + "SwitchElm", 368, 100, 368, 160, 0, new StringTokenizer("true false"));
//    switchElm.setPoints();
//
//    var resistorElm:ResistorElm = constructElement(ClassSubPath + "ResistorElm", 368, 160, 368, 220, 0, new StringTokenizer("1000"));
//    resistorElm.setPoints();
//
//    var capacitorElm:CapacitorElm = constructElement(ClassSubPath + "CapacitorElm", 368, 220, 368, 300, 0, new StringTokenizer(".000001 0"));
//    capacitorElm.setPoints();
//
//    var groundElm:GroundElm = constructElement(ClassSubPath + "GroundElm", 368, 300, 368, 340, 0, null);
//    groundElm.setPoints();
//
//    elmList.push(voltageElm);
//
//
//    elmList.push(resistorElm);
//    elmList.push(groundElm);
//    elmList.push(switchElm);
//    elmList.push(capacitorElm);
//
//    nodeList = new Array();
//
//    handleResize();
//    needAnalyze();

//    var resistor = new ResistorElm(50, 50, 50, 100, 0, "500");
//    CirSim.elmList.push(resistor);

    CirSim.nodeList = [];
	CirSim.needAnalyze();

    //CirSim.updateCircuit();

    //document.write((resistor instanceof resistorElement) + ', ' + (resistor instanceof circuitElement) + '<BR/>');
    //resistor.draw();
};
////////////////////////////////////////////////////////
// EVENT HANDLERS GO HERE:
////////////////////////////////////////////////////////

/** Not yet implemented */
CirSim.onKeyPressed = function(evt)  {
    CirSim.warning("Key Pressed!");
    //TODO: IMPLEMENT
    //    if (e.getKeyChar() > ' ' && e.getKeyChar() < 127) {
    //    Class c = dumpTypes[e.getKeyChar()];
    //    if (c == null || c == Scope.class)
    //        return;
    //        CircuitElement elm = null;
    //        elm = constructElement(c, 0, 0);
    //        if (elm == null || !(elm.needsShortcut() && elm.getDumpClass() == c))
    //            return;
    //        mouseMode = MODE_ADD_ELM;
    //        mouseModeStr = c.getName();
    //        addingClass = c;
    //        }
    //        if (e.getKeyChar() == ' ') {
    //            mouseMode = MODE_SELECT;
    //            mouseModeStr = "Select";
    //        }
    //        tempMouseMode = mouseMode;
};

/** Key released not used */
CirSim.onKeyReleased = function(evt) {
    // Not used
}

CirSim.onMouseDragged = function( evt ) {
    //TODO: IMPLEMENT
    // ignore right mouse button with no modifiers (needed on PC)
    //    if ((e.getModifiers() & MouseEvent.BUTTON3_MASK) != 0) {
    //        int ex = e.getModifiersEx();
    //        if ((ex & (MouseEvent.META_DOWN_MASK |
    //            MouseEvent.SHIFT_DOWN_MASK |
    //            MouseEvent.CTRL_DOWN_MASK |
    //            MouseEvent.ALT_DOWN_MASK)) == 0)
    //            return;
    //    }

    CirSim.warning("onMouseDragged");

    // X and Y mouse position
    var x = evt.pageX-CanvasBoundingBox.x;
    var y = evt.pageY-CanvasBoundingBox.y;
    
    if (!CirSim.circuitArea.contains(x, y))
        return;
    if (CirSim.dragElm != null)
        CirSim.dragElm.drag(x, y);
    var success = true;
    switch (CirSim.tempMouseMode) {
        case CirSim.MODE_DRAG_ALL:
            CirSim.dragAll(CirSim.snapGrid(x), CirSim.snapGrid(y));
            break;
        case CirSim.MODE_DRAG_ROW:
            CirSim.dragRow(CirSim.snapGrid(x), CirSim.snapGrid(y));
            break;
        case CirSim.MODE_DRAG_COLUMN:
            CirSim.dragColumn(CirSim.snapGrid(x), CirSim.snapGrid(y));
            break;
        case CirSim.MODE_DRAG_POST:
            if (CirSim.mouseElm != null)
                CirSim.dragPost(CirSim.snapGrid(x), CirSim.snapGrid(y));
            break;
        case CirSim.MODE_SELECT:
            if (CirSim.mouseElm == null)
                CirSim.selectArea(x, y);
            else {
                CirSim.tempMouseMode = CirSim.MODE_DRAG_SELECTED;
                success = CirSim.dragSelected(x, y);
            }
            break;
        case CirSim.MODE_DRAG_SELECTED:
            success = CirSim.dragSelected(x, y);
            break;
    }
    CirSim.dragging = true;
    if (success) {
        if (CirSim.tempMouseMode == CirSim.MODE_DRAG_SELECTED && CirSim.mouseElm instanceof TextElm) {
            CirSim.dragX = x;
            CirSim.dragY = y;
        } else {
            CirSim.dragX = CirSim.snapGrid(x);
            CirSim.dragY = CirSim.snapGrid(y);
        }
    }
    //root.repaint();
};

CirSim.dragAll = function(x, y) {
    //TODO: test
    var dx = x - CirSim.dragX;
    var dy = y - CirSim.dragY;
    if (dx == 0 && dy == 0)
        return;
    var i;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        ce.move(dx, dy);
    }
    CirSim.removeZeroLengthElements();
};

CirSim.dragRow = function(x, y) {
    //TODO: test
    var dy = y - CirSim.dragY;
    if (dy == 0)
        return;
    var i;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        if (ce.y == CirSim.dragY)
            ce.movePoint(0, 0, dy);
        if (ce.y2 == CirSim.dragY)
            ce.movePoint(1, 0, dy);
    }
    CirSim.removeZeroLengthElements();
};


CirSim.onMouseMove = function( evt ) {
//    TODO: TEST

    // X and Y mouse position
    var x = evt.pageX-CanvasBoundingBox.x;
    var y = evt.pageY-CanvasBoundingBox.y;

    console.log("MOVE: " + x + "  " + y + " " + evt.which);
    if ( evt.which != 0 || evt.button != 0) {
        CirSim.onMouseDragged(evt);
        return;
    }

    CirSim.error("onMouseMove: " + x + ", " + y);


    CirSim.dragX = CirSim.snapGrid(x);
    CirSim.dragY = CirSim.snapGrid(y);

    CirSim.draggingPost = -1;

    var i;
    var origMouse = CirSim.mouseElm;

    CirSim.mouseElm = null;
    CirSim.mousePost = -1;

    CirSim.plotXElm = CirSim.plotYElm = null;
    var bestDist = 1e7;
    var bestArea = 1e7;

    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        if (ce.boundingBox.contains(x, y)) {
            var j;
            var area = ce.boundingBox.width * ce.boundingBox.height;
            var jn = ce.getPostCount();
            if (jn > 2)
                jn = 2;
            for (j = 0; j != jn; j++) {
                var pt = ce.getPost(j);
                var distance = CirSim.distanceSq(x, y, pt.x, pt.y);

                // if multiple elements have overlapping bounding boxes,
                // we prefer selecting elements that have posts close
                // to the mouse pointer and that have a small bounding
                // box area.
                if (distance <= bestDist && area <= bestArea) {
                    bestDist = distance;
                    bestArea = area;
                    CirSim.mouseElm = ce;
                }
            }
            if (ce.getPostCount() == 0)
                CirSim.mouseElm = ce;
        }
    }

    CirSim.scopeSelected = -1;
    if (CirSim.mouseElm == null) {
        // TODO: Add scopes
        //				for (i = 0; i != scopeCount; i++) {
        //					var s:Scope = scopes[i];
        //					if (s.rect.contains(x, y)) {
        //						s.select();
        //						scopeSelected = i;
        //					}
        //				}
        // the mouse pointer was not in any of the bounding boxes, but we
        // might still be close to a post
        for (i = 0; i != CirSim.elmList.length; i++) {
            var ce = CirSim.getElm(i);
            var j;
            var jn = ce.getPostCount();
            for (j = 0; j != jn; j++) {
                var pt = ce.getPost(j);

                var distance = CirSim.distanceSq(x, y, pt.x, pt.y);
                if (CirSim.distanceSq(pt.x, pt.y, x, y) < 26) {
                    CirSim.mouseElm = ce;
                    CirSim.mousePost = j;
                    break;
                }
            }
        }
    } else {
        CirSim.mousePost = -1;
        // look for post close to the mouse pointer
        for (i = 0; i != CirSim.mouseElm.getPostCount(); i++) {
            var pt = CirSim.mouseElm.getPost(i);
            if (CirSim.distanceSq(pt.x, pt.y, x, y) < 26)
                CirSim.mousePost = i;
        }
    }
    //if (CircuitSimulator.mouseElm != origMouse)
    //	this.repaint();
};

CirSim.onMouseClicked = function(evt) {

    // TODO: IMPLEMENT
    console.log("CLICK: " + evt.pageX + "  " + evt.pageY);
    CirSim.warning("onMouseClicked: " + evt.pageX + ", " + evt.pageY);

    if (evt.button == 0) {
    if (CirSim.mouseMode == CirSim.MODE_SELECT || CirSim.mouseMode == CirSim.MODE_DRAG_SELECTED)
        CirSim.clearSelection();
}
};

CirSim.onMouseEntered = function(evt) {
    // TODO: IMPLEMENT
};

CirSim.onMouseExited = function(evt) {
    // TODO: IMPLEMENT
    CirSim.scopeSelected = -1;
    CirSim.mouseElm = CirSim.plotXElm = CirSim.plotYElm = null;

};

CirSim.onMousePressed = function(evt) {
    //TODO: IMPLEMENT
    console.log(evt.toString());
//    var ex = evt.getModifiersEx();
//
//    if ((ex & (MouseEvent.META_DOWN_MASK |
//        MouseEvent.SHIFT_DOWN_MASK)) == 0 && e.isPopupTrigger()) {
//        doPopupMenu(e);
//        return;
//    }

    // X and Y mouse position
    var x = evt.pageX-CanvasBoundingBox.x;
    var y = evt.pageY-CanvasBoundingBox.y;

    CirSim.warning("onMousePressed " + x + ", " + y);

    if (evt.button == 0) {
    //left mouse
    CirSim.tempMouseMode = CirSim.mouseMode;
    if ( evt.altKey )
        CirSim.tempMouseMode = CirSim.MODE_DRAG_ALL;
    else if ( evt.altKey && evt.shiftKey )
        CirSim.tempMouseMode = CirSim.MODE_DRAG_ROW;
    else if ( evt.shiftKey )
        CirSim.tempMouseMode = CirSim.MODE_SELECT;
    //else if ((ex & MouseEvent.ALT_DOWN_MASK) != 0)
    //	tempMouseMode = MODE_DRAG_ALL;
    else if ( evt.ctrlKey)
        CirSim.tempMouseMode = CirSim.MODE_DRAG_POST;
    }

    /*else if ((e.getModifiers() & MouseEvent.BUTTON3_MASK) != 0) {
        // right mouse
        if ((ex & MouseEvent.SHIFT_DOWN_MASK) != 0)
        tempMouseMode = MODE_DRAG_ROW;
        else if ((ex & (MouseEvent.CTRL_DOWN_MASK |
        MouseEvent.META_DOWN_MASK)) != 0)
        tempMouseMode = MODE_DRAG_COLUMN;
        else
        return;
    }*/

    if (CirSim.tempMouseMode != CirSim.MODE_SELECT && CirSim.tempMouseMode != CirSim.MODE_DRAG_SELECTED)
        CirSim.clearSelection();

    if ( CirSim.doSwitch(x, y) )
        return;

    //pushUndo();

    CirSim.initDragX = x;
    CirSim.initDragY = y;
    CirSim.dragging = true;

    //if (tempMouseMode != MODE_ADD_ELM || addingClass == null)
    //	return;

    var x0 = CirSim.snapGrid(x);
    var y0 = CirSim.snapGrid(y);
    if (!CirSim.circuitArea.contains(x0, y0))
        return;

    //dragElm = constructElement(addingClass, x0, y0);
};

CirSim.onMouseReleased = function( evt ) {
    //TODO: test
//    int ex = e.getModifiersEx();
//    if(evt.shiftKey || evt.ctrlKey ) {
//
//    }

//    if ((ex & (MouseEvent.SHIFT_DOWN_MASK | MouseEvent.CTRL_DOWN_MASK |
//        MouseEvent.META_DOWN_MASK)) == 0 && e.isPopupTrigger()) {
//        doPopupMenu(e);
//        return;
//    }

    CirSim.warning("onMouseReleased: " + evt.pageX + ", " + evt.pageY);

    CirSim.tempMouseMode = CirSim.mouseMode;
    CirSim.selectedArea = null;
    CirSim.dragging = false;
    var circuitChanged = false;

    if (CirSim.heldSwitchElm) {
        CirSim.heldSwitchElm.mouseUp();
        CirSim.heldSwitchElm = null;
        circuitChanged = true;
    }

    if (CirSim.dragElm != null) {
        // if the element is zero size then don't create it
        if (CirSim.dragElm.x == CirSim.dragElm.x2 && CirSim.dragElm.y == CirSim.dragElm.y2)
            CirSim.dragElm.destroy();
        else {
            CirSim.elmList.push(CirSim.dragElm);
            circuitChanged = true;
        }
        CirSim.dragElm = null;
    }

    if (circuitChanged)
        CirSim.needAnalyze();
    if (CirSim.dragElm != null)
        CirSim.dragElm.destroy();
    CirSim.dragElm = null;
    //root.repaint();
};



CirSim.dragColumn = function(x, y) {
    //TODO: test
    var dx = x - CirSim.dragX;
    if (dx == 0)
        return;
    var i;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        if (ce.x == CirSim.dragX)
            ce.movePoint(0, dx, 0);
        if (ce.x2 == CirSim.dragX)
            ce.movePoint(1, dx, 0);
    }
    CirSim.removeZeroLengthElements();
};

CirSim.dragSelected = function( x, y)  {
    //TODO: test
    var me = false;
    if (CirSim.mouseElm != null && !CirSim.mouseElm.isSelected())
        CirSim.mouseElm.setSelected(me = true);

    // snap grid, unless we're only dragging text elements
    var i;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        if (ce.isSelected() && !(ce instanceof TextElm))
            break;
    }
    if (i != CirSim.elmList.length) {
        x = CirSim.snapGrid(x);
        y = CirSim.snapGrid(y);
    }

    var dx = x - CirSim.dragX;
    var dy = y - CirSim.dragY;
    if (dx == 0 && dy == 0) {
        // don't leave mouseElm selected if we selected it above
        if (me)
            CirSim.mouseElm.setSelected(false);
        return false;
    }
    var allowed = true;

    // check if moves are allowed
    for (i = 0; allowed && i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        if (ce.isSelected() && !ce.allowMove(dx, dy))
            allowed = false;
    }

    if (allowed) {
        for (i = 0; i != CirSim.elmList.length; i++) {
            var ce = CirSim.getElm(i);
            if (ce.isSelected())
                ce.move(dx, dy);
        }
        CirSim.needAnalyze();
    }

    // don't leave mouseElm selected if we selected it above
    if (me)
        CirSim.mouseElm.setSelected(false);

    return allowed;
};

CirSim.dragPost = function(x, y) {
    // TODO: test
    if (CirSim.draggingPost == -1) {
        CirSim.draggingPost =
            (CirSim.distanceSq(CirSim.mouseElm.x, CirSim.mouseElm.y, x, y) >
                CirSim.distanceSq(CirSim.mouseElm.x2, CirSim.mouseElm.y2, x, y)) ? 1 : 0;
    }
    var dx = x - CirSim.dragX;
    var dy = y - CirSim.dragY;
    if (dx == 0 && dy == 0)
        return;

    CirSim.mouseElm.movePoint(CirSim.draggingPost, dx, dy);
    CirSim.needAnalyze();
};

CirSim.dumpCircuit = function() {
	var i;

	var f = (CirSim.dotsCheckItem) ? 1 : 0;
	f |= (CirSim.smallGridCheckItem) ? 2 : 0;
	f |= (CirSim.voltsCheckItem) ? 0 : 4;
	f |= (CirSim.powerCheckItem) ? 8 : 0;
	f |= (CirSim.showValuesCheckItem) ? 0 : 16;

	// 32 = linear scale in afilter
	var dump = "$ " + f + " " + CirSim.timeStep + " " + CirSim.getIterCount() + " " + CirSim.currentBar + " " + CircuitElement.voltageRange + " " + CirSim.powerBar + "\n";

	for( i = 0; i != CirSim.elmList.length; i++)
	dump += CirSim.getElm(i).dump() + "\n";

    // TODO: Implement scope
//	for( i = 0; i != CirSim.scopeCount; i++) {
//		var d = CirSim.scopes[i].dump();
//		if(d != null)
//			dump += d + "\n";
//	}

	if(CirSim.hintType != -1)
		dump += "h " + CirSim.hintType + " " + CirSim.hintItem1 + " " + CirSim.hintItem2 + "\n";

	return dump;
};

CirSim.selectArea = function(x, y) {
    var x1 = Math.min(x, CirSim.initDragX);
    var x2 = Math.max(x, CirSim.initDragX);
    var y1 = Math.min(y, CirSim.initDragY);
    var y2 = Math.max(y, CirSim.initDragY);
    CirSim.selectedArea = new Rectangle(x1, y1, x2 - x1, y2 - y1);
    var i;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        ce.selectRect(CirSim.selectedArea);
    }
};

/** todo: test */
CirSim.removeZeroLengthElements = function() {
    var i;
    var changed = false;
    for (i = CirSim.elmList.length - 1; i >= 0; i--) {
        var ce = CirSim.getElm(i);
        if (ce.x == ce.x2 && ce.y == ce.y2) {
            // TODO: Make sure this works
            CirSim.elmList.splice(i, 1);
            ce.destroy();
            changed = true;
        }
    }
    CirSim.needAnalyze();
};

/** TODO: NOT YET PORTED */
CirSim.doCut = function() {
//    int i;
//    pushUndo();
//    setMenuSelection();
//    clipboard = "";
//    for (i = elmList.size() - 1; i >= 0; i--) {
//        CircuitElm ce = getElm(i);
//        if (ce.isSelected()) {
//            clipboard += ce.dump() + "\n";
//            ce.delete();
//            elmList.removeElementAt(i);
//        }
//    }
//    enablePaste();
//    needAnalyze();
};

/** TODO: NOT YET PORTED */
CirSim.doCopy = function() {
//    int i;
//    clipboard = "";
//    setMenuSelection();
//    for (i = elmList.size() - 1; i >= 0; i--) {
//        CircuitElm ce = getElm(i);
//        if (ce.isSelected())
//            clipboard += ce.dump() + "\n";
//    }
//    enablePaste();
};

// TODO: Test!
CirSim.doDelete = function() {
    var i;
    CirSim.pushUndo();
    CirSim.setMenuSelection();
    for (i = CirSim.elmList.length - 1; i >= 0; i--) {
        var ce = CirSim.getElm(i);
        if (ce.isSelected()) {
            ce.destroy();
            CirSim.elmList.splice(i, 1)
        }
    }
    CirSim.needAnalyze();
};

CirSim.enablePaste = function() {
    pasteMenuItem.setEnabled(CirSim.clipboard.length() > 0);
};

/** Not yet ported */
CirSim.doPaste = function() {
    // TODO: NOT YET PORTED
};

CirSim.clearSelection = function() {
    var i;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        ce.setSelected(false);
    }
};

CirSim.doSelectAll = function() {
    var i;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        ce.setSelected(true);
    }
};

CirSim.setGrid = function() {
    CirSim.gridSize = (CirSim.smallGridCheckItem) ? 8 : 16;
    CirSim.gridMask = ~(CirSim.gridSize - 1);
    CirSim.gridRound = CirSim.gridSize / 2 - 1;
};

CirSim.drawGrid = function() {

    var numCols = (CanvasBoundingBox.width / CirSim.gridSize);
    var numRows = (CanvasBoundingBox.height / CirSim.gridSize);

    // Draw cols:
    for(var i=0; i<numCols; i++) {
        for( var j=0; j<numRows; ++j) {
            paper.rect(CirSim.gridSize*i, CirSim.gridSize*j, 1, 1).attr( {
                'stroke':Color.color2HexString(Color.DEEP_YELLOW),
                'stroke-width':.2
        } );
        }
    }

};

CirSim.handleResize = function() {
    //TODO: Probably not needed.
};

CirSim.destroyFrame = function() {
    //TODO: Probably not needed.
};

CirSim.getHint = function() {

	var c1 = CirSim.getElm(CirSim.hintItem1);
	var c2 = CirSim.getElm(CirSim.hintItem2);

	if(c1 == null || c2 == null)
		return null;
	if(CirSim.hintType == CirSim.HINT_LC) {
		if(!( c1 instanceof InductorElm))
			return null;
		if(!( c2 instanceof CapacitorElm))
			return null;
		var ie = c1;
		// as InductorElm;
		var ce = c2;
		// as CapacitorElm;
		return "res.f = " + CircuitElement.getUnitText(1 / (2 * Math.PI * Math.sqrt(ie.inductance * ce.capacitance)), "Hz");
	}
	if(CirSim.hintType == CirSim.HINT_RC) {
		if(!( c1 instanceof ResistorElm))
			return null;
		if(!( c2 instanceof CapacitorElm))
			return null;
		var re = c1;
		// as ResistorElm;
		var ce = c2;
		// as CapacitorElm;
		return "RC = " + CircuitElement.getUnitText(re.resistance * ce.capacitance, "s");
	}
	if(CirSim.hintType == CirSim.HINT_3DB_C) {
		if(!( c1 instanceof ResistorElm))
			return null;
		if(!( c2 instanceof CapacitorElm))
			return null;
		var re = c1;
		// as ResistorElm;
		var ce = c2;
		// as CapacitorElm;
		return "f.3db = " + CircuitElement.getUnitText(1 / (2 * Math.PI * re.resistance * ce.capacitance), "Hz");
	}
	if(CirSim.hintType == CirSim.HINT_3DB_L) {
		if(!( c1 instanceof ResistorElm))
			return null;
		if(!( c2 instanceof InductorElm))
			return null;
		var re = c1;
		// as ResistorElm;
		var ie = c2;
		// as InductorElm;
		return "f.3db = " + CircuitElement.getUnitText(re.resistance / (2 * Math.PI * ie.inductance), "Hz");
	}
	if(CirSim.hintType == CirSim.HINT_TWINT) {
		if(!( c1 instanceof ResistorElm))
			return null;
		if(!( c2 instanceof CapacitorElm))
			return null;
		var re = c1;
		// as ResistorElm;
		var ce = c2;
		// as CapacitorElm;
		return "fc = " + CircuitElement.getUnitText(1 / (2 * Math.PI * re.resistance * ce.capacitance), "Hz");
	}

	return null;
};

CirSim.snapGrid = function(x) {
    return (x + CirSim.gridRound) & CirSim.gridMask;
};

CirSim.toggleSwitch = function(n) {
    var i;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var ce = CirSim.getElm(i);
        if (ce instanceof SwitchElm) {
            n--;
            if (n == 0) {
                (ce).toggle();
                CirSim.analyzeFlag = true;
                //cv.repaint();
                return;
            }
        }
    }
};

CirSim.doSwitch = function(x, y) {
	if(CirSim.mouseElm == null || !(CirSim.mouseElm instanceof SwitchElm))
		return false;

	var se = CirSim.mouseElm;
	// as SwitchElm;
	se.toggle();

	if(se.momentary)
		CirSim.heldSwitchElm = se;

    CirSim.needAnalyze();
	return true;
};

CirSim.getIterCount = function() {
	if(CirSim.speedBar == 0)
		return 0;
	//return (Math.exp((speedBar.getValue()-1)/24.) + .5);
	return .1 * Math.exp((CirSim.speedBar - 61) / 24.);
};

CirSim.needAnalyze = function() {
	CirSim.analyzeFlag = true;
};

CirSim.getCircuitNode = function(n)  {
    if(n >= CirSim.nodeList.length)
        return new CircuitNode();

    return CirSim.nodeList[n];//[n] as CircuitNode;
};

CirSim.getElm = function(n) {
	if(n >= CirSim.elmList.length)
		return null;
	return CirSim.elmList[n];
	// as CircuitElement;
};

CirSim.halt = function(s, ce) {
	CirSim.stopMessage = s;
	CirSim.circuitMatrix = null;
	CirSim.stopElm = ce;
	CirSim.stoppedCheck = true;
	CirSim.analyzeFlag = false;

	console.log("Error: " + s);
	//cv.repaint();
	// TODO: Put error message here
};

// ERRORS AND WARNINGS: //////////////////////////////////////////////////////////////////////
CirSim.errorMsg = "";
CirSim.warningMsg = "";


CirSim.error = function(msg) {
    CirSim.errorMsg = msg;
    CirSim.drawError();
};

CirSim.drawError = function() {
    paper.text(150, Settings.WINDOW_HEIGHT-50, CirSim.errorMsg).attr('fill', Color.color2HexString(Settings.ERROR_COLOR));
};


CirSim.warning = function(msg) {
    CirSim.warningMsg = msg;
    CirSim.drawWarning();
};

CirSim.drawWarning = function() {
    paper.text(150, Settings.WINDOW_HEIGHT-70, CirSim.warningMsg).attr('fill', Color.color2HexString(Settings.WARNING_COLOR));
};

///////////////////////////////////////////////////////////////////////////////////////////////
CirSim.updateCircuit = function() {
	var startTime = (new Date()).getTime();

	// Reset the page:
	paper.clear();

    //CirSim.drawGrid();

	var realMouseElm;
	// CircuitElement

	// TODO
	//if(winSize == null || winSize.width == 0)
	//	return;

    // Draw Warning and error messages:
    CirSim.drawError();
    CirSim.drawWarning();

	if(CirSim.analyzeFlag) {
		CirSim.analyzeCircuit();
		CirSim.analyzeFlag = false;
	}

    // TODO
//	if(CirSim.editDialog != null && CirSim.editDialog.elm instanceof CircuitElement)
//		CirSim.mouseElm = CirSim.editDialog.elm;
	// as CircuitElement;

	realMouseElm = CirSim.mouseElm;

	if(CirSim.mouseElm == null)
		CirSim.mouseElm = CirSim.stopElm;

	// TODO
	//setupScopes();

    CircuitElement.selectColor = Settings.SELECT_COLOR;

	if(CirSim.printableCheckItem) {
		CircuitElement.whiteColor = Color.WHITE;
        CircuitElement.lightGrayColor = Color.BLACK;
	} else {
        CircuitElement.whiteColor = Color.WHITE;
        CircuitElement.lightGrayColor = Color.LIGHT_GREY;
	}

	if(!CirSim.stoppedCheck) {
		try {
			CirSim.runCircuit();
		} catch ( e ) {
			console.log(e.message);
			CirSim.analyzeFlag = true;

			//cv.paint(g);
			return;
		}
	}

    CirSim.currentBar = 50;

	if(!CirSim.stoppedCheck) {

		var sysTime = (new Date()).getTime();
		if(CirSim.lastTime != 0) {
			var inc = Math.floor(sysTime - CirSim.lastTime);
			var c = CirSim.currentBar;
			//55; 	// The value of CirSim number must be carefully set for current to display properly

			//console.log("Frame time: " + inc  + "   #: "  + frames);

			c = Math.exp(c / 3.5 - 14.2);
			CircuitElement.currentMult = 1.7 * inc * c;
            console.log("cur: " + CircuitElement.currentMult + " cb: " + CirSim.currentBar);
			if(!CirSim.conventionCheckItem)
                CircuitElement.currentMult = -CircuitElement.currentMult;

		}
		if(sysTime - CirSim.secTime >= 1000) {
			CirSim.framerate = CirSim.frames;
			CirSim.steprate = CirSim.steps;
			CirSim.frames = 0;
			CirSim.steps = 0;
			CirSim.secTime = sysTime;
		}

		CirSim.lastTime = sysTime;
	} else {
		CirSim.lastTime = 0;
	}

    CircuitElement.powerMult = Math.exp(CirSim.powerBar / 4.762 - 7);

	for(var i = 0; i < CirSim.elmList.length; ++i) {
		CirSim.getElm(i).draw();
	}

	if(CirSim.tempMouseMode == CirSim.MODE_DRAG_ROW || CirSim.tempMouseMode == CirSim.MODE_DRAG_COLUMN || CirSim.tempMouseMode == CirSim.MODE_DRAG_POST || CirSim.tempMouseMode == CirSim.MODE_DRAG_SELECTED) {

		for( i = 0; i < CirSim.elmList.length; ++i) {
			var ce = CirSim.getElm(i);
            ce.drawPost(ce.x, ce.y);
            ce.drawPost(ce.x2, ce.y2);
		}

	}

	var badNodes = 0;

	// find bad connections. Nodes not connected to other elements which intersect other elements' bounding boxes
	for( i = 0; i < CirSim.nodeList.length; ++i) {
		var cn = CirSim.getCircuitNode(i);

		if(!cn.intern && cn.links.length == 1) {
			var bb = 0;
			var cn1 = cn.links[0];
			// CircuitNodeLink
			for(var j = 0; j < CirSim.elmList.length; ++j) {

				if(cn1.elm != CirSim.getElm(j) && CirSim.getElm(j).boundingBox.contains(cn.x, cn.y))
					bb++;
			}
			if(bb > 0) {
                // Outline bad nodes
                paper.circle(cn.x, cn.y, 2*Settings.POST_RADIUS).attr({
                    'stroke':Color.color2HexString(Color.RED),
                    'stroke-dasharray':'--'
                });
				badNodes++;
			}
		}
	}

	if(CirSim.dragElm != null && (CirSim.dragElm.x != CirSim.dragElm.x2 || CirSim.dragElm.y != CirSim.dragElm.y2))
		CirSim.dragElm.draw(null);

	var ct = CirSim.scopeCount;

	if(CirSim.stopMessage != null)
		ct = 0;

	// TODO Implement scopes
	//for(i=0; i!=ct; ++i) {}
	//scopes[i].draw(g);

	if(CirSim.stopMessage != null) {
		printError(CirSim.stopMessage);
	} else {
		if(CirSim.circuitBottom == 0)
			CirSim.calcCircuitBottom();

		var info = [];
		// Array of messages to be displayed at the bottom of the canvas
		if(CirSim.mouseElm != null) {
			if(CirSim.mousePost == -1)
				CirSim.mouseElm.getInfo(info);
			else
				info[0] = "V = " + CircuitElement.getUnitText(CirSim.mouseElm.getPostVoltage(CirSim.mousePost), "V");
		} else {
			CircuitElement.showFormat.fractionalDigits = 2;
			info[0] = "t = " + CircuitElement.getUnitText(CirSim.t, "s") + "\nf.t.: " + (CirSim.lastTime - CirSim.lastFrameTime) + "\n";
		}
		if(CirSim.hintType != -1) {
			for( i = 0; info[i] != null; ++i) {
			}
			var s = CirSim.getHint();
			if(s == null)
				CirSim.hintType = -1;
			else
				info[i] = s;
		}
		var x = 0;

        // TODO: Implement scopes
//		if(ct != 0)
//			x = CirSim.scopes[ct - 1].rightEdge() + 20;

		x = Math.max(x, CanvasBoundingBox.width * 2 / 3);

		for( i = 0; info[i] != null; ++i) {
		}
		if(badNodes > 0)
			info[++i] = badNodes + ((badNodes == 1) ? " bad connection" : " bad connections");

        var bottomTextOffset = 100;
		// Find where to show data; below ciruit, not too high unless we need it
		var ybase = CanvasBoundingBox.height - 15 * i - bottomTextOffset;
		ybase = Math.min(ybase, CirSim.circuitArea.height);
		ybase = Math.max(ybase, CirSim.circuitBottom);

		 for( i=0; info[i] != null; ++i )
             paper.text(x, ybase + 15 * (i+1), info[i]).attr('fill', Color.color2HexString(Settings.TEXT_COLOR));


	}

    // Draw selection outline:
    if(CirSim.selectedArea != null) {
        paper.rect(this.selectedArea.x, this.selectedArea.y, this.selectedArea.width, this.selectedArea.height).attr('stroke', Color.color2HexString(Settings.SELECTION_MARQUEE_COLOR) );
    }

	CirSim.mouseElm = realMouseElm;
	CirSim.frames++;

	var endTime = (new Date()).getTime();
	var computationTime = (endTime - startTime);

    paper.text(100, 15, "Frame: " + CirSim.frames + "\nComputationTime: " + computationTime).attr('fill', Color.color2HexString(Settings.TEXT_COLOR));
	//console.log("Computation Time: " + computationTime);

	//CirSim.Main.getMainCanvas().setSimulationInfoText("Sim: sp: " + CirSim.speedBar + "\ncurSpeed: " + CirSim.currentBar + "\nt.s.:" + CirSim.timeStep + "\nvrange: " + CircuitElement.voltageRange);

	CirSim.lastFrameTime = CirSim.lastTime;
};

CirSim.analyzeCircuit = function() {
	
	CirSim.calcCircuitBottom();
	if(CirSim.elmList.length==0) 
		return;
		
	CirSim.stopMessage = null;
	CirSim.stopElm = null;
	
	var i;
	var j;
	
	var vscount = 0; // int
	
	CirSim.nodeList = [];
	
	var gotGround = false;
	var gotRail = false;
	
	var volt = null;	// CircuitElement
	
	for( i=0; i<CirSim.elmList.length; ++i ) {
		var ce = CirSim.getElm(i); // CircuitElement type
		
		if( ce instanceof GroundElm ) {
			gotGround = true;
			break;
		}
		if(ce instanceof RailElm)
			gotRail = true;
		if(volt == null && ce instanceof VoltageElm)
			volt = ce;
	}
	
	// If no ground and no rails then voltage element's first terminal instanceof referenced to ground:
	if(!gotGround && volt != null && !gotRail) {
		var cn = new CircuitNode();
		
		var pt = volt.getPost(0);
		cn.x = pt.x;
		cn.y = pt.y;
		CirSim.nodeList.push(cn);
	} else {
		// Else allocate extra node for ground
		var cn = new CircuitNode();
		cn.x = cn.y = -1;
		CirSim.nodeList.push(cn);
	}
	
	// Allocate nodes and voltage sources
	for(i=0; i<CirSim.elmList.length; ++i) {
		var ce = CirSim.getElm(i);
		
		var inodes = ce.getInternalNodeCount();
		var ivs = ce.getVoltageSourceCount();
		var posts = ce.getPostCount();
		
		// allocate a node for each post and match posts to nodes
		for(j=0; j != posts; ++j) {
			var pt = ce.getPost(j);
			
			var k;
			for( k=0; k != CirSim.nodeList.length; ++k ) {
				var cn = CirSim.getCircuitNode(k);
				if(pt.x == cn.x && pt.y == cn.y)
					break;
			}
			if( k==CirSim.nodeList.length ) {
				var cn = new CircuitNode();
				cn.x = pt.x;
				cn.y = pt.y;
				var cn1 =  new CircuitNodeLink();
				cn1.num = j;
				cn1.elm = ce;
				cn.links.push(cn1);
				ce.setNode(j, CirSim.nodeList.length);
				CirSim.nodeList.push(cn);
			} else {
				var cn1 = new CircuitNodeLink();
				cn1.num = j;
				cn1.elm = ce;
				CirSim.getCircuitNode(k).links.push(cn1);
				ce.setNode(j, k);
				// If it's the ground node, make sure the node voltage instanceof 0, because it may not get set later.
				if(k==0)
					ce.setNodeVoltage(j, 0);
			}
			
		}
		for(j=0; j!=inodes; ++j) {
			var cn = new CircuitNode();
			
			cn.x = -1;
			cn.y = -1;
			cn.intern = true;
			
			var cn1 = new CircuitNodeLink();
			cn1.num = j+posts;
			cn1.elm = ce;
			cn.links.push(cn1);
			ce.setNode(cn1.num, CirSim.nodeList.length);
			CirSim.nodeList.push(cn);
		}
		vscount += ivs;
	}
	
	CirSim.voltageSources = new Array(vscount);
	vscount = 0;
	CirSim.circuitNonLinear = false;
	
	// determine if circuit instanceof nonlinear
	for( i=0; i != CirSim.elmList.length; ++i ) {
		var ce = CirSim.getElm(i);		// circuitElement
		if(ce.nonLinear())
			CirSim.circuitNonLinear = true;
		var ivs = ce.getVoltageSourceCount();
		for(j=0; j != ivs; ++j) {
			CirSim.voltageSources[vscount] = ce;
			ce.setVoltageSource(j, vscount++);
		}
	}
	
	CirSim.voltageSourceCount = vscount;
	
	var matrixSize = CirSim.nodeList.length-1 + vscount;
	CirSim.circuitMatrix = initializeTwoDArray( matrixSize, matrixSize);
	CirSim.origMatrix = initializeTwoDArray( matrixSize, matrixSize);
	
	CirSim.circuitRightSide = new Array(matrixSize);
    // Todo: check array length
	/*circuitRightSide = */zeroArray(CirSim.circuitRightSide);
	CirSim.origRightSide = new Array(matrixSize);
	/*origRightSide = */zeroArray(CirSim.origRightSide);
	CirSim.circuitMatrixSize = CirSim.circuitMatrixFullSize = matrixSize;
	
	CirSim.circuitRowInfo = new Array(matrixSize);
	CirSim.circuitPermute = new Array(matrixSize);
    // Todo: check
	/*circuitRowInfo = */zeroArray(CirSim.circuitRowInfo);
	/*circuitPermute = */zeroArray(CirSim.circuitPermute);
	
	for( i=0; i!=matrixSize; ++i) {
		CirSim.circuitRowInfo[i] = new RowInfo();
	}
	
	CirSim.circuitNeedsMap = false;

	// stamp linear circuit elements
	for(i=0; i != CirSim.elmList.length; ++i) {
		var ce = CirSim.getElm(i);
		ce.stamp();
	}
	
	var closure = new Array(CirSim.nodeList.length);
	var changed = true;
	
	closure[0] = true;
	
	while(changed) {
		changed = false;
		for( i=0; i != CirSim.elmList.length; ++i ) {
			var ce = CirSim.getElm(i);
			
			// Loop through all ce's nodes to see if theya are connected to otehr nodes not in closure
			for(j=0; j<ce.getPostCount(); ++j) {
				if(!closure[ce.getNode(j)]) {
					if(ce.hasGroundConnection(j))
						closure[ce.getNode(j)] = changed = true;
					continue;
				}
				
				var k;
				for(k=0; k!= ce.getPostCount(); ++k) {
					if(j==k)
						continue;
					var kn = ce.getNode(k);
					if(ce.getConnection(j, k) &&!closure[kn]) {
						closure[kn] = true;
						changed = true;
					}
				}
			}
		}
		
		if(changed)
			continue;
		
		// connect unconnected nodes
		for(i=0; i!=CirSim.nodeList.length; ++i) {
			if(!closure[i] && !CirSim.getCircuitNode(i).intern) {
				console.log("node " + i + " unconnected");
				CirSim.stampResistor(0, i, 1e8);
				closure[i] = true;
				changed = true;
				break;
			}
		}
	}
	
	for(i=0; i!=CirSim.elmList.length; ++i) {
		var ce = CirSim.getElm(i);
		
		if( ce instanceof InductorElm ) {
			var fpi = new FindPathInfo(FindPathInfo.INDUCT, ce, ce.getNode(1), CirSim.elmList, CirSim.nodeList.length);
			
			// try findPath with maximum depth of 5, to avoid slowdown
			if( !fpi.findPath(ce.getNode(0), 5) && !fpi.findPath(ce.getNode(0)) ) {
				console.log(ce.toString() + " no path");
				ce.reset();
			}
		}
		
		// look for current sources with no current path
		if(ce instanceof CurrentElm) {
			var fpi = new FindPathInfo(FindPathInfo.INDUCT, ce, ce.getNode(1), CirSim.elmList, CirSim.nodeList.length);
			
			if(!fpi.findPath(ce.getNode(0))) {
                CirSim.halt("No path for current source!", ce);
				return;
			}
		}
		
		// Look for voltage soure loops:
		if( (ce instanceof VoltageElm && ce.getPostCount() == 2) || ce instanceof WireElm ) {
			var fpi = new FindPathInfo(FindPathInfo.VOLTAGE, ce, ce.getNode(1), CirSim.elmList, CirSim.nodeList.length);
			
			if( fpi.findPath(ce.getNode(0))==true ) {
                CirSim.halt("Voltage source/wire loop with no resistance!", ce);
				return;
			}
		}

		// Look for shorted caps or caps with voltage but no resistance
		if( ce instanceof CapacitorElm ) {
			var fpi = new FindPathInfo( FindPathInfo.SHORT, ce, ce.getNode(1), CirSim.elmList, CirSim.nodeList.length );
			
			if( fpi.findPath(ce.getNode(0)) ) {
				console.log( ce.toString() + " shorted");
				ce.reset();
			} else {
				
				fpi = new FindPathInfo( FindPathInfo.CAP_V, ce, ce.getNode(1), CirSim.elmList, CirSim.nodeList.length );
				if( fpi.findPath(ce.getNode(0)) ) {
					CirSim.halt("Capacitor loop with no resistance!", ce);
					return;
				}
			
			}
		}
	
	}
	
	for( i=0; i != matrixSize; ++i) {
		var qm = -1;
		var qp = -1;
		var qv = 0;
		var re = CirSim.circuitRowInfo[i];
		
		if(re.lsChanges || re.dropRow || re.rsChanges)
			continue;
		
		var rsadd = 0;
		
		// look for rows that can be removed
		for( j=0; j != matrixSize; ++j) {
			var q = CirSim.circuitMatrix[i][j];
			if(CirSim.circuitRowInfo[j].type == RowInfo.ROW_CONST) {
				// Keep a running total of const values that have been removed already
				rsadd -= CirSim.circuitRowInfo[j].value * q;
				continue;
			}
			if(q==0)
				continue;
			if(qp == -1) {
				qp = j;
				qv = q;
				continue;
			}
			if(qm == -1 && q == -qv) {
				qm = j;
				continue;
			}
			break;
		}
		
		//console.log("line " + i + " " + qp + " " + qm + " " + j);
		/*if (qp != -1 && circuitRowInfo[qp].lsChanges) {
            console.log("lschanges");
            continue;
		}
		if (qm != -1 && circuitRowInfo[qm].lsChanges) {
            console.log("lschanges");
            continue;
		}*/
		
		if( j==matrixSize) {
			if(qp == -1) {
				CirSim.halt("Matrix error", null);
				return;
			}
			
			var elt = CirSim.circuitRowInfo[qp];
			if(qm == -1) {
				// We found a row with only one nonzero entry, that value instanceof constant
				var k;
				for(k=0; elt.type == RowInfo.ROW_EQUAL && k < 100; ++k) {
					// Follow the chain
					qp = elt.nodeEq;
					elt = CirSim.circuitRowInfo[qp];
				}
				if (elt.type == RowInfo.ROW_EQUAL) {
					// break equal chains
					//System.out.println("Break equal chain");
					elt.type = RowInfo.ROW_NORMAL;
					continue;
				}
				if (elt.type != RowInfo.ROW_NORMAL) {
					console.log("type already " + elt.type + " for " + qp + "!");
					continue;
				}
				
				elt.type = RowInfo.ROW_CONST;
				elt.value = (CirSim.circuitRightSide[i] + rsadd) / qv;
				CirSim.circuitRowInfo[i].dropRow = true;
				//console.log(qp + " * " + qv + " = const " + elt.value);
				i = -1; // start over from scratch
			} else if (CirSim.circuitRightSide[i] + rsadd == 0) {
				// we found a row with only two nonzero entries, and one
				// instanceof the negative of the other; the values are equal
				if (elt.type != RowInfo.ROW_NORMAL) {
					//console.log("swapping");
					var qq = qm;
					qm = qp;
					qp = qq;
					elt = CirSim.circuitRowInfo[qp];
					if (elt.type != RowInfo.ROW_NORMAL) {
						// we should follow the chain here, but this hardly ever happens so it's not worth worrying about
						console.log("swap failed");
						continue;
					}
				}
				elt.type = RowInfo.ROW_EQUAL;
				elt.nodeEq = qm;
				CirSim.circuitRowInfo[i].dropRow = true;
				//console.log(qp + " = " + qm);
			} // end elseif
			
		} // end if(j==matrixSize)
		
	} // end for(matrixSize)
	
	// find size of new matrix:
	var nn = 0;
	for(i=0; i!= matrixSize; ++i) {
		var elt = CirSim.circuitRowInfo[i];
		if (elt.type == RowInfo.ROW_NORMAL) {
			elt.mapCol = nn++;
			//System.out.println("col " + i + " maps to " + elt.mapCol);
			continue;
		}
		if (elt.type == RowInfo.ROW_EQUAL) {
			var e2 = null;
			// resolve chains of equality; 100 max steps to avoid loops
			for (j = 0; j != 100; j++) {
				e2 = CirSim.circuitRowInfo[elt.nodeEq];
				if (e2.type != RowInfo.ROW_EQUAL)
					break;
				if (i == e2.nodeEq)
					break;
				elt.nodeEq = e2.nodeEq;
			}
		}
		if (elt.type == RowInfo.ROW_CONST)
			elt.mapCol = -1;
	} // END for
	
	for (i = 0; i != matrixSize; i++) {
		var elt = CirSim.circuitRowInfo[i];
		if (elt.type == RowInfo.ROW_EQUAL) {
			var e2 = CirSim.circuitRowInfo[elt.nodeEq];
			if (e2.type == RowInfo.ROW_CONST) {
				// if something instanceof equal to a const, it's a const
				elt.type = e2.type;
				elt.value = e2.value;
				elt.mapCol = -1;
				//System.out.println(i + " = [late]const " + elt.value);
			} else {
				elt.mapCol = e2.mapCol;
				//System.out.println(i + " maps to: " + e2.mapCol);
			}
		}
	}
	
	// make the new, simplified matrix
	var newsize = nn;
	var newmatx = initializeTwoDArray( newsize, newsize);
	
	var newrs = new Array(newsize);
	/*var newrs:Array = */zeroArray(newrs);
	var ii = 0;
	for (i = 0; i != matrixSize; i++) {
		var rri = CirSim.circuitRowInfo[i];
		if (rri.dropRow) {
			rri.mapRow = -1;
			continue;
		}
		newrs[ii] = CirSim.circuitRightSide[i];
		rri.mapRow = ii;
		//System.out.println("Row " + i + " maps to " + ii);
		for (j = 0; j != matrixSize; j++) {
			var ri = CirSim.circuitRowInfo[j];
			if (ri.type == RowInfo.ROW_CONST)
				newrs[ii] -= ri.value * CirSim.circuitMatrix[i][j];
			else
				newmatx[ii][ri.mapCol] += CirSim.circuitMatrix[i][j];
		}
		ii++;
	}

    CirSim.circuitMatrix = newmatx;
    CirSim.circuitRightSide = newrs;
	matrixSize = CirSim.circuitMatrixSize = newsize;
	for (i = 0; i != matrixSize; i++)
		CirSim.origRightSide[i] = CirSim.circuitRightSide[i];
	for (i = 0; i != matrixSize; i++)
		for (j = 0; j != matrixSize; j++)
            CirSim.origMatrix[i][j] = CirSim.circuitMatrix[i][j];
    CirSim.circuitNeedsMap = true;
	
	/* // For debugging
	console.log("matrixSize = " + matrixSize + " " + circuitNonLinear);
	for (j = 0; j != circuitMatrixSize; j++) {
		for (i = 0; i != circuitMatrixSize; i++)
			console.log(circuitMatrix[j][i] + " ");
		console.log("  " + circuitRightSide[j] + "\n");
	}
	console.log("\n");
	*/
	
	// if a matrix instanceof linear, we can do the lu_factor here instead of
	// needing to do it every frame
	if (!CirSim.circuitNonLinear) {
		if (!CirSim.lu_factor(CirSim.circuitMatrix, CirSim.circuitMatrixSize, CirSim.circuitPermute)) {
			CirSim.halt("Singular matrix!", null);
			return;
		}
	}
	
};

CirSim.calcCircuitBottom = function() {
    var i;
    CirSim.circuitBottom = 0;
    for (i = 0; i != CirSim.elmList.length; i++) {
        var rect = CirSim.getElm(i).boundingBox;
        var bottom = rect.height + rect.y;
        if (bottom > CirSim.circuitBottom)
            CirSim.circuitBottom = bottom;
    }
};

/* ported */
CirSim.locateElm = function( elm ) {
    var i;
    for (i = 0; i != CirSim.elmList.length; i++)
        if (elm == CirSim.elmList[i])
            return i;
    return -1;
};

/** control voltage source vs with voltage from n1 to n2 (must
 also call stampVoltageSource()) */
CirSim.stampVCVS = function(n1, n2, coef, vs ) {
    var vn = CirSim.nodeList.length + vs;
    CirSim.stampMatrix(vn, n1, coef);
    CirSim.stampMatrix(vn, n2, -coef);
};

/** stamp independent voltage source #vs, from n1 to n2, amount v */
CirSim.stampVoltageSource = function(n1, n2, vs, v) {
    var vn = CirSim.nodeList.length + vs;
    CirSim.stampMatrix(vn, n1, -1);
    CirSim.stampMatrix(vn, n2, 1);
    CirSim.stampRightSide(vn, v);
    CirSim.stampMatrix(n1, vn, 1);
    CirSim.stampMatrix(n2, vn, -1);
};

CirSim.updateVoltageSource = function(n1, n2, vs, v) {
    var vn = CirSim.nodeList.length + vs;
    CirSim.stampRightSide(vn, v);
};

CirSim.stampResistor = function(n1, n2, r) {
    var r0 = 1 / r;
    if (isNaN(r0) || isInfinite(r0)) {
        console.log("bad resistance " + r + " " + r0 + "\n");
        var tempError = new Error();
        //var stackTrace = tempError.getStackconsole.log);
        console.log("bad resistance ");
        var a = 0;
        a /= a;
    }

    console.log("Stamp resistor: " + n1 + " " + n2 + " " + r + " " );
    CirSim.stampMatrix(n1, n1, r0);
    CirSim.stampMatrix(n2, n2, r0);
    CirSim.stampMatrix(n1, n2, -r0);
    CirSim.stampMatrix(n2, n1, -r0);
};

CirSim.stampConductance = function(n1, n2, r0) {
    CirSim.stampMatrix(n1, n1, r0);
    CirSim.stampMatrix(n2, n2, r0);
    CirSim.stampMatrix(n1, n2, -r0);
    CirSim.stampMatrix(n2, n1, -r0);
};

/** current from cn1 to cn2 is equal to voltage from vn1 to 2, divided by g */
CirSim.stampVCCurrentSource = function(cn1, cn2, vn1, vn2, g) {
    CirSim.stampMatrix(cn1, vn1, g);
    CirSim.stampMatrix(cn2, vn2, g);
    CirSim.stampMatrix(cn1, vn2, -g);
    CirSim.stampMatrix(cn2, vn1, -g);
};

CirSim.stampCurrentSource = function(n1, n2, i) {
    CirSim.stampRightSide(n1, -i);
    CirSim.stampRightSide(n2, i);
};

/** stamp a current source from n1 to n2 depending on current through vs */
CirSim.stampCCCS = function(n1, n2, vs, gain) {
    var vn = CirSim.nodeList.length + vs;
    CirSim.stampMatrix(n1, vn, gain);
    CirSim.stampMatrix(n2, vn, -gain);
};

/** stamp value x in row i, column j, meaning that a voltage change
 of dv in node j will increase the current into node i by x dv.
 (Unless i or j is a voltage source node.)
 */
CirSim.stampMatrix = function(i, j, x) {
    if (i > 0 && j > 0) {
        if (CirSim.circuitNeedsMap) {
            i = CirSim.circuitRowInfo[i - 1].mapRow;
            var ri = CirSim.circuitRowInfo[j - 1];
            if (ri.type == RowInfo.ROW_CONST) {
                //console.log("Stamping constant " + i + " " + j + " " + x);
                CirSim.circuitRightSide[i] -= x * ri.value;
                return;
            }
            j = ri.mapCol;
            //console.log("stamping " + i + " " + j + " " + x);
        } else {
            i--;
            j--;
        }
        CirSim.circuitMatrix[i][j] += x;
    }
};

/** stamp value x on the right side of row i, representing an
 independent current source flowing into node i
 */
CirSim.stampRightSide = function(i, x) {
    if(isNaN(x)) {
        console.log("rschanges true " + (i-1));
        if (i > 0)
            CirSim.circuitRowInfo[i - 1].rsChanges = true;
    }else {
        if (i > 0) {
            if (CirSim.circuitNeedsMap) {
                i = CirSim.circuitRowInfo[i - 1].mapRow;
                console.log("stamping rs " + i + " " + x);
            } else
                i--;
            CirSim.circuitRightSide[i] += x;
        }
    }
};

/** Indicate that the values on the left side of row i change in doStep() */
CirSim.stampNonLinear = function( i ) {
    if (i > 0)
        CirSim.circuitRowInfo[i - 1].lsChanges = true;
};

/** Todo: Check if working */
CirSim.getCodeBase = function() {
    return "";
};

CirSim.runCircuit = function() {

    if(CirSim.circuitMatrix == null || CirSim.elmList.length == 0 ) {
        CirSim.circuitMatrix = null;
        return;
    }

    var iter;
    var debugPrint = CirSim.dumpMatrix;

    CirSim.dumpMatrix = false;

    var steprate = 160*CirSim.getIterCount();

    var tm = (new Date()).getTime();
    var lit = CirSim.lastIterTime;

    // Double-check
    if( 1000 >= steprate * (tm - CirSim.lastIterTime) ) {
        console.log("returned: diff: " + (tm-CirSim.lastIterTime));
        return;
    }

    // Main iteration
    for(iter=1; ; ++iter) {

        var i;
        var j;
        var k;
        var subiter;

        // Start Iteration for each element in the circuit
        for( i=0; i<CirSim.elmList.length; ++i ) {
            var ce = CirSim.getElm(i);
            ce.startIteration();
        }

        // Keep track of the number of steps
        ++CirSim.steps;

        // The number of maximum allowable iterations
        var subiterCount = 5000;

        // Sub iteration
        for(subiter=0; subiter<subiterCount; subiter++) {
            CirSim.converged = true;

            CirSim.subIterations = subiter;

            for( i=0; i<CirSim.circuitMatrixSize; ++i )
                CirSim.circuitRightSide[i] = CirSim.origRightSide[i];
            if(CirSim.circuitNonLinear) {
                for(i=0; i<CirSim.circuitMatrixSize; ++i)
                    for(j=0; j<CirSim.circuitMatrixSize; ++j)
                        CirSim.circuitMatrix[i][j] = CirSim.origMatrix[i][j];
            }

            // Step each element this iteration
            for(i=0; i<CirSim.elmList.length; ++i) {
                var ce = CirSim.getElm(i);
                ce.doStep();
            }

            if(CirSim.stopMessage != null)
                return;

            var printit = debugPrint;
            debugPrint = false;
            for(j=0; j<CirSim.circuitMatrixSize; ++j) {
                for(i=0; i<CirSim.circuitMatrixSize; ++i ) {
                    var x = CirSim.circuitMatrix[i][j];
                    if(isNaN(x) || isInfinite(x) ) {
                        console.log("Matrix is invalid (NaN)");
                        CirSim.halt("NaN matrix", null);
                        return;
                    }
                }
            }

//            if(printit) {
//                for(j=0; i<circuitMatrixSize; j++) {
//                    for( i=0; i<circuitMatrixSize; ++i)
//                        console.logcircuitMatrix[j][i] + ",");
//                    console.log(" " + circuitRightSide[j] + "\n");
//                }
//                console.log("\n");
//            }
//
            if(CirSim.circuitNonLinear) {
                if( CirSim.converged && subiter>0 )
                    break;

                if( !CirSim.lu_factor(CirSim.circuitMatrix, CirSim.circuitMatrixSize, CirSim.circuitPermute) ) {
                    CirSim.halt("Singular matrix!", null);
                    return;
                }

            }

            CirSim.lu_solve(CirSim.circuitMatrix, CirSim.circuitMatrixSize, CirSim.circuitPermute, CirSim.circuitRightSide);

            for( j=0; j<CirSim.circuitMatrixFullSize; ++j ) {
                var ri = CirSim.circuitRowInfo[j];
                var res = 0;

                if(ri.type == RowInfo.ROW_CONST)
                    res = ri.value;
                else
                    res = CirSim.circuitRightSide[ri.mapCol];

                if( isNaN(res) ) {
                    CirSim.converged = false;
                    break;
                }

                if(j < (CirSim.nodeList.length - 1)) {

                    var cn = CirSim.getCircuitNode(j+1);
                    for(k=0; k<cn.links.length; ++k) {
                        var cn1 = cn.links[k];// as CircuitNodeLink;

                        cn1.elm.setNodeVoltage(cn1.num, res);
                    }
                } else {
                    var ji = j - (CirSim.nodeList.length-1);
                    //console.log("setting vsrc " + ji + " to " + res);
                    CirSim.voltageSources[ji].setCurrent(ji, res);
                }

            }

            if(!CirSim.circuitNonLinear)
                break;

        }	// End for

        if(subiter > 5)
            console.log("converged after " + subiter + " iterations");
        if(subiter >= subiterCount) {
            CirSim.halt("Convergence failed: " + subiter, null);
            break;
        }

        CirSim.t += CirSim.timeStep;
        //for(i=0; i<scopeCount; ++i)
        //	scopes[i].timeStep();

        tm = (new Date()).getTime();
        lit = tm;

        console.log("diff: " + (tm-CirSim.lastIterTime) + " iter: " + iter + " ");
        if(iter*1000 >= steprate * (tm - CirSim.lastIterTime) ) {
            console.log("1 breaking from iteration: " + " sr: " + steprate + " iter: " + iter + " time: " + tm + " lastIterTime: " + CirSim.lastIterTime + " lastFrametime: " + CirSim.lastFrameTime );
            break;
        } else if (tm - CirSim.lastFrameTime > 500) {
            console.log("2 breaking from iteration: " + " sr: " + steprate + " iter: " + iter + " time: " + tm + " lastIterTime: " + CirSim.lastIterTime + " lastFrametime: " + CirSim.lastFrameTime );
            break;
        }

    }

    CirSim.lastIterTime = lit;
};

/** initializes the values of scalefactors for performance reasons */
CirSim.initScaleFactors = function()  {
    var numScaleFactors = 200;
    for(var i=0; i<numScaleFactors; ++i ) {
        CirSim.scaleFactors[i] = 0;
    }
};

/** Input array a is a two dimensional array */
CirSim.lu_factor = function( a, n, ipvt ) {

    ///*var scaleFactors:Array = */ArrayUtils.initializeOneDArray(scaleFactors, n);	// Array of numbers
    //console.log("N: " + n);

    var i;
    var j;
    var k;

    console.log("N: " + n);

    // Divide each row by largest element in that row and remember scale factors
    for( i=0; i<n; ++i ) {
        var largest = 0;

        for( j=0; j<n; ++j ) {
            var x = Math.abs(a[i][j]);
            if (x>largest)
                largest = x;
        }
        // Check for singular matrix:
        if( largest==0 )
            return false;
        CirSim.scaleFactors[i] = 1.0/largest;
    }

    // Crout's method: Loop through columns first
    for(j=0; j<n; ++j) {

        // Calculate upper trangular elements for this column:
        for( i=0; i<j; ++i) {
            var q = a[i][j];

            for(k=0; k!=i; ++k)
                q -= a[i][k] * a[k][j];

            a[i][j] = q;
        }

        // Calculate lower triangular elements for this column
        var largest = 0;
        var largestRow = -1;

        for(i=j; i<n; ++i) {
            var q = a[i][j];

            for(k=0; k<j; ++k)
                q -= a[i][k]*a[k][j];

            a[i][j] = q;
            var x = Math.abs(q);

            if( x>= largest) {
                largest = x;
                largestRow = i;
            }
        }

        // Pivot
        if (j != largestRow) {
            var x;

            for( var k=0; k<n; ++k ) {
                x = a[largestRow][k];
                a[largestRow][k] = a[j][k];
                a[j][k] = x;
            }
            CirSim.scaleFactors[largestRow] = CirSim.scaleFactors[j];
        }

        // keep track of row interchanges
        ipvt[j] = largestRow;

        // avoid zeros
        if( a[j][j] == 0) {
            //console.log("avoided zero");
            a[j][j] = 1e-18;
        }

        if (j!=n-1) {
            var mult = 1/ a[j][j];
            for(i=j+1; i != n; ++i)
                a[i][j] *= mult;
        }

    }

    return true;
};

/** Solves the factored matrix */
CirSim.lu_solve = function( a, n, ipvt, b )  {
    var i;

    // find first nonzero b element
    for(i=0; i<n; ++i ) {
        var row = ipvt[i];

        var swap = b[row];
        b[row] = b[i];
        b[i] = swap;
        if(swap != 0)
            break;
    }

    var bi = i++;
    for(; i<n; ++i) {
        var row = ipvt[i];
        var j;
        var tot = b[row];

        b[row] = b[i];
        // Forward substitution by using the lower triangular matrix;
        for( j=bi; j<i; ++j )
            tot -= a[i][j] * b[j];
        b[i] = tot;

    }

    for( i=n-1; i>=0; i--) {
        var tot = b[i];

        // back-substitution using the upper triangular matrix
        var j;
        for( j=i+1; j!=n; ++j )
            tot -= a[i][j] * b[j];
        b[i] = tot / a[i][i];

    }
};

CirSim.snapGrid  = function(x) {
    return (x + CirSim.gridRound) & CirSim.gridMask;
};

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
// END: CIRCUIT ANALYSIS CODE
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
// CIRCUIT FILE IO
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//
//var setupListLoader:URLLoader;
//var defaultCircuitLoader:URLLoader;
//
//public function loadSetupFile() : void {
//    setupListLoader = new URLLoader();
//setupListLoader.addEventListener(Event.COMPLETE, onSetupListLoadComplete);
//setupListLoader.load(new URLRequest(getCodeBase() + "setupList.txt"));
//}
//
///** Loads the file for the specified circuit */
//public function loadDefaultCircuitFile( circuitName:String, title:String ) : void {
//    defaultCircuitLoader = new URLLoader();
//defaultCircuitLoader.addEventListener( Event.COMPLETE, onDefaultCircuitLoadComplete );
//defaultCircuitLoader.load( new URLRequest("circuits/"+circuitName) );
//}
//
//private function onSetupListLoadComplete( evt:Event ) : void {
//
//var stack:Array = new Array();
//var stackptr:int = 0;
///*stack[stackptr++] = menu;*/
//
//try {
//    var ba:String = setupListLoader.data as String;
//    var b:String = ba; // copy?
//    var len:int = ba.length;
//    var p:int;
//
//    if (len == 0 || b.charAt(0) != '#') {
//        // got a redirect, try again
//        onSetupListLoadComplete( evt /*menu, */);
//        return;
//    }
//
//    for (p = 0; p < len;) {
//        var l:int;
//        for (l = 0; l != len - p; l++) {
//            if (b.charAt(l + p) == '\n') {
//                l++;
//                break;
//            }
//        }
//        var line:String = b.substr(p, l-1);//encodeString(b);//new String(b, p, l - 1);
//        if (line.charAt(0) == '#') {} // Do nothing on comment
//
//        else if (line.charAt(0) == '+') {
//            //var n:Menu = new Menu(line.substring(1));
//            /*menu.add(n);*/
//            /*menu = stack[stackptr++] = n;*/
//        } else if (line.charAt(0) == '-') {
//            /*menu = stack[--stackptr - 1];*/
//        } else {
//            var i:int = line.indexOf(' ');
//            if (i > 0) {
//
//                var title:String = line.substring(i + 1);
//                var first:Boolean = false;
//
//                if (line.charAt(0) == '>')
//                    first = true;
//
//                var file:String = line.substring(first ? 1 : 0, i);
//
//                // Add object to our class mapping
//                menuMapping[title] = "setup " + file;
//                //menu.add( getMenuItem(title, "setup " + file) );
//
//                if (first && startCircuit == null) {
//                    startCircuit = file;
//                    startLabel = title;
//                }
//            }
//        }
//        p += l;
//    }
//} catch ( e:Error ) {
//    console.log("Error: " + e.message);
//    halt("Can't read setuplist.txt! " + e.getStackconsole.log), null);
//}
//
//// Now that the setup file is finished loading, load the default circuit as specified.
//
////if (useFrame)
////setMenuBar(mb);
//if (startCircuitText != null)
//    readSetup(startCircuitText);
//else if (stopMessage == null && startCircuit != null)
//    loadDefaultCircuitFile(startCircuit, startLabel);
//
//
//}
//
//private function onDefaultCircuitLoadComplete(evt:Event) : void {
//    readDefaultCircuit(defaultCircuitLoader.data as String, defaultCircuitLoader.data.length, true);
//}
//
//private function readSetup(text:String, retain:Boolean = false) : void {
//    readDefaultCircuit(text, text.length, retain);
////titleLabel.setText("untitled");
//}
//
//private function readSetupArray( stream:FileStreamWithLineReader ) : void {
//var bytes:ByteArray;
//stream.readBytes(bytes);
//
//var byteLength:uint = stream.bytesAvailable;
//}

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
// LOCAL UTILITY FUNCTIONS
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////



///** Converts a ByteArray into its corresponding String */
//CirSim.encodeString = function(ba) {
//    var origPos = ba.position;
//    var result = new Array();
//
//    for (ba.position = 0; ba.position < ba.length - 1; )
//        result.push(ba.readShort());
//
//    if (ba.position != ba.length)
//        result.push(ba.readByte() << 8);
//
//    ba.position = origPos;
//
//    return String.fromCharCode.apply(null, result);
//}

/** Computes the Euclidean distance between two points */
CirSim.distanceSq = function(x1, y1, x2, y2) {
    x2 -= x1;
    y2 -= y1;
    return x2 * x2 + y2 * y2;
};


/** Converts a String into its corresponding ByteArray */
//CirSim.decodeString = function(str) {
//    var result = new ByteArray();
//    for (var i = 0; i < str.length; ++i) {
//        result.writeShort(str.charCodeAt(i));
//    }
//    result.position = 0;
//    return result;
//};

CirSim.readHint = function(st) {
    var hints = st.split(" ");
    CirSim.hintType = hints[0];
    CirSim.hintItem1 = hints[1];
    CirSim.hintItem2 = hints[2];
};

//private function readOptions( st ) : void {
//
//    var flags:int = int(st.nextToken());
//
//    dotsCheckItem = ((flags & 1) != 0);
//    smallGridCheckItem = ((flags & 2) != 0);
//    voltsCheckItem = ((flags & 4) == 0);
//    powerCheckItem = ((flags & 8) == 8);
//    showValuesCheckItem = ((flags & 16) == 0);
//    timeStep = Number(st.nextToken());
//
//    var sp:Number = Number(st.nextToken());
//    var sp2:int = int(Math.log(10 * sp) * 24 + 61.5);
//
//    //int sp2 = (int) (Math.log(sp)*24+1.5);
//    speedBar = sp2;
//    currentBar = int(st.nextToken());
//
//    var vrange:Number = Number(st.nextToken());
//    CircuitElement.voltageRange = vrange;
//
//    //			try {
//    powerBar = int(st.nextToken());
//    //			} catch (e:Error) {
//    //			}
//
//    setGrid();
//}


