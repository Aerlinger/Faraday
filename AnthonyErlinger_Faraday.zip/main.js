
var iterationNum = 0;
function iterate() {
    iterationNum++;
    console.log("iteration " + iterationNum);
    CirSim.updateCircuit();
};

function start() {
    console.log("starting simulation");

};

if(!console.log) {
    console.log = function() {};
}

function setupUI() {

};

function intervalTrigger() {
    console.log("Starting simulation");
    setInterval( function() {
        CirSim.updateCircuit();
    }, 40 );
};

$(document).ready(function(e) {

    console.log("Started!");

    var canvas = $('#canvas_container');

    CanvasBoundingBox = new Rectangle(canvas.offset().left, canvas.offset().top, canvas.width(), canvas.height());

    paper = new Raphael(document.getElementById('canvas_container'), canvas.width(), canvas.height());


    $("#canvas_container").css({
        'background-color': Color.color2HexString(Settings.BG_COLOR),//Settings.BG_COLOR.toString(16),
        'border-width': '2px'
    });

    $("#canvas_container").click( function(event) {
        event.preventDefault();
        CirSim.onMouseClicked(event);
    });

    //TODO:
//    $("#canvas_container").mousedragged( function(event) {
//
//    });

    $("#canvas_container").mouseenter( function(event) {
        CirSim.onMouseEntered(event);
    });

    $("#canvas_container").mouseleave( function(event) {
        CirSim.onMouseExited(event);
    });

    $("#canvas_container").mousemove( function(event) {
        event.preventDefault();
        CirSim.onMouseMove(event);
    });

    $("#canvas_container").mousedown( function(event) {
        event.preventDefault();
        CirSim.onMousePressed(event);
    });

    $("#canvas_container").mouseup( function(event) {
        event.preventDefault();
        CirSim.onMouseReleased(event);
    });

    $("#canvas_container").keypress( function(event) {
        alert(event.which);
        event.preventDefault();
        CirSim.onKeyPressed(event);
    });

    CirSim.init();
    CirSim.initCircuit();

    intervalTrigger();




});









