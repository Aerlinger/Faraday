function TextElm( xa, ya, xb, yb, f, st ) {

};