function RailElm( xa, ya, xb, yb, f, st ) {

};