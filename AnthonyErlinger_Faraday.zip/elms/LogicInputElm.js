function LogicInputElm( xa, ya, xb, yb, f, st ) {

};