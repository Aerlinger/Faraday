function SweepElm( xa, ya, xb, yb, f, st ) {

};

