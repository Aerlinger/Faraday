

function CurrentElm( xa, ya, xb, yb, f, st ) {


};